package Appointment;

public interface Bookable {
	public String isOnSameTime(Appointment A);
}
